# BURRITO

Janky-ass pelican theme.

See it in action: http://burrito.sh

## Requirements

`pip install webassets cssmin`

Add `assets` to the `PLUGINS` list in your pelicanconf:

`PLUGINS = ['assets']`
